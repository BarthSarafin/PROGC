/* Datei: queue.cpp
   Autor: Marc Rennhard
   Datum: 16.05.2010

   Implementierung fuer die Queue;
   Teil von Queue */

#include "queue.h"

// Constructor
template <class Type> Queue<Type>::Queue() {
  data = new Type[INIT_SIZE];
  size = INIT_SIZE;
  indexPut = 0;
  indexGet = 0;
}

// Destructor
template <class Type> Queue<Type>::~Queue() {
  delete[] data;
}

// Gibt das vorderste Element zurueck
template <class Type> Type Queue<Type>::getElement() {
  if (indexPut > indexGet) {
    return data[indexGet++];
  } else {
    throw EmptyQueueException();
  }
}

// Fuegt ein Element in die Queue ein
template <class Type> void Queue<Type>::putElement(const Type& elem) {

  // Ende des Arrays erreicht?
  if (indexPut >= size) {
    
    // Pruefen, ob bereits MAX_ELEM im Array vorhanden sind
    if ((indexPut - indexGet) == MAX_ELEM) {
        throw FullQueueException<Type>(data[indexPut - 1]);
    }
	 
    // Noch nicht MAX_ELEM
    unsigned int newsize = (INIT_SIZE + indexPut - indexGet);
    if (newsize > MAX_ELEM) {
      newsize = MAX_ELEM;
    }

    // Neuen Array anlegen
    int *temp = new Type[newsize];
    size = newsize;
        
    // Daten umkopieren
    for (unsigned i = 0; i < (indexPut-indexGet); i++) {
      temp[i] = data[indexGet + i];
    }
        
    // Indexzeiger fuer neues Array einstellen
    indexPut = indexPut - indexGet;
    indexGet = 0;
        
    // Alten Array loeschen
    delete[] data;
        
    // Zeiger auf neues Array
    data = temp;
  }
    
  // Element speichern und Zeiger weiterstellen
  data[indexPut] = elem;
  indexPut++;
}
