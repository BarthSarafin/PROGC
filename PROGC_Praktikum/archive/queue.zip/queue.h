/* Datei: queue.h
   Autor: Marc Rennhard
   Datum: 16.05.2010

   Spezifikation fuer die Queue;
   Teil von Queue */

#ifndef QUEUE_H
#define QUEUE_H

#define INIT_SIZE 5
#define MAX_ELEM 100

/*
 * Spezifikation der Klasse Queue
 */
template <class Type> class Queue {
private:
  Type* data;
  unsigned int indexPut, indexGet;
  unsigned int size;

public:
  Queue();
  ~Queue();
    
  // Naechstes Element aus der Queue holen
  Type getElement();
    
  // Neues Element in die Queue einfuegen
  void putElement(const Type& elem);
};

/*
 * Drei Exceptions, Spezifikation und Implementierung
 * nicht getrennt; generische Queue Exception und je
 * eine f¸r den Empty und Full Queue
 */
class QueueException{};

class EmptyQueueException : public QueueException{};

template <class Type> class FullQueueException : public QueueException {
private:
	Type& lastElement;
	
public:
	FullQueueException(Type& elem) : lastElement(elem) {
		lastElement = elem;
	}
	Type getLastElement() {
		return lastElement;
	}
};

#endif
