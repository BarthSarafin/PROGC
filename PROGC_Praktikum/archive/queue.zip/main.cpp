/* Datei: main.cpp
   Autor: Marc Rennhard
   Datum: 16.05.2010

   Hauptprogramm fuer die Queue;
   Teil von Queue */

#include <iostream>
#include "queue.cpp"
using namespace std;

// Hauptprogramm
int main() {
  Queue<int> intQueue;
  int i;
  
  // Test 1: Zahlen 1-5 einfuegen, entfernen und ausgeben
  cout << "Test 1: Sollte 1 - 5 ausgeben:" << endl;
  for (i = 1; i <= 5; ++i) {
    intQueue.putElement(i);
  }
  for (i = 1; i <= 5; ++i) {
    cout << intQueue.getElement() << endl;
  }
  cout << endl;
  
  // Test 2: Zahlen 1-15 einfuegen, entfernen und ausgeben
  cout << "Test 2: Sollte 1 - 15 ausgeben:" << endl;  
  for (i = 1; i <= 15; ++i) {
    intQueue.putElement(i);
  }
  for (i = 1; i <= 15; ++i) {
    cout << intQueue.getElement() << endl;
  }
  cout << endl;

  // Test 3: Zahlen 1-10 einfuegen und 11 Zahlen entfernen und ausgeben
  cout << "Test 3: Sollte 1 - 10 ausgeben und nachfolgend eine " 
       << "EmptyQueueException abfangen:" << endl;
  for (i = 1; i <= 10; ++i) {
    intQueue.putElement(i);
  }
  try {
    for (i = 1; i <= 11; ++i) {
      cout << intQueue.getElement() << endl;
    }
  } catch (EmptyQueueException &e) {
    cout << "EmptyQueueException abgefangen" << endl;
  }
  cout << endl;
  
  // Test 4: 101 Elemente eingeben
  cout << "Test 4: Sollte eine FullQueueException abfangen und 100 als "
       << "letztes Element ausgeben:" << endl;
  try {
    for (i = 1; i <= 101; ++i) {
      intQueue.putElement(i);
    }
  } catch (FullQueueException<int> &e) {
    cout << "FullQueueException abgefangen, letztes Element = " 
         << e.getLastElement() << endl;
  }
}
