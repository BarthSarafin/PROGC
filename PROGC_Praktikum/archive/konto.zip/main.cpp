/* Datei: main.cpp
   Autor: Marc Rennhard, urspruenglich Peter Frueh
   Datum: 03.07.2006

   Hauptprogramm um die verschiedenen Konten zu
   testen; Teil von Kontoverwaltung */

#include <iostream>
#include "konto.h"
using namespace std;

int main() {
  int i;
  double z;

  // Konten auf NULL setzen
  Konto* bank[10];
  Nummernkonto* bankNr[10];
  for (i = 0; i < 10; i++) {
    bank[i] = NULL;
    bankNr[i] = NULL;
  }

  // Konten er�ffnen
  bank[0] = new Konto("Fredi Meier");
  bank[1] = new Konto("Sepp Semmel");
  bank[2] = new Kontokorrent("Jogi Baer", 1000);
  bank[3] = new Kontokorrent("John Wayne", 10000);
  bankNr[0] = new Nummernkonto("Werner K. Rey", 27);
  bankNr[1] = new Nummernkonto("Martin Ebner", 55);
  bankNr[2] = new Nummernkontokorrent("Fix Foxi", 500, 105);
  bankNr[3] = new Nummernkontokorrent("Dirk Doedel", 1500, 199);

  // Auf alle Konten 10000 einzahlen
  for (i = 0; bank[i] != NULL; i++) {
    bank[i]->einzahlen(10000);
  }
  for (i = 0; bankNr[i] != NULL; i++) {
    bankNr[i]->einzahlen(10000);
  }
  
  // Alle Konten ausgeben
  cout << "Nach Kontoeroeffnung und Einzahlen von 10000:" << endl;
  for (i = 0; bank[i] != 0; i++) {
    cout << *bank[i] << endl;
  }
  for (i = 0; bankNr[i] != 0; i++) {
    cout << *bankNr[i] << endl;
  }
  cout << endl;

  // Zinssatz setzen
  Konto::setZinssatz(0.03);
  Kontokorrent::setZinssatz(0.05);

  // Alle Konten ausgeben
  cout << "Nach Setzen des Zinssatzes:" << endl;
  for (i = 0; bank[i] != 0; i++) {
    cout << *bank[i] << endl;
  }
  for (i = 0; bankNr[i] != 0; i++) {
    cout << *bankNr[i] << endl;
  }
  cout << endl;

  // Ueberall 12000 auszahlen und ausgeben
  cout << "Ausgabe bei gewuenschten 12000, sollte 10000, 10000" << endl;
  cout << "11000, 12000, 10000, 10000, 10500, 11500 sein:" << endl;
  for (i = 0; bank[i] != 0; i++) {
    cout << bank[i]->auszahlen(12000) << endl;
  }
  for (i = 0; bankNr[i] != 0; i++) {
    cout << bankNr[i]->auszahlen(12000) << endl;
  }
  cout << endl;

  // Alle Konten ausgeben
  cout << "Nach Auszahlen von 12000:" << endl;
  for (i = 0; bank[i] != 0; i++) {
    cout << *bank[i] << endl;
  }
  for (i = 0; bankNr[i] != 0; i++) {
    cout << *bankNr[i] << endl;
  }
  cout << endl;

  // Ueberall 100000 einzahlen
  for (i = 0; bank[i] != 0; i++) {
    bank[i]->einzahlen(100000);
  }
  for (i = 0; bankNr[i] != 0; i++) {
    bankNr[i]->einzahlen(100000);
  }
  
  // Alle Konten ausgeben
  cout << "Nach Einzahlen von 100000:" << endl;
  for (i = 0; bank[i] != 0; i++) {
    cout << *bank[i] << endl;
  }
  for (i = 0; bankNr[i] != 0; i++) {
    cout << *bankNr[i] << endl;
  }
  cout << endl;

  // Zins berechnen und einzahlen
  for (i = 0; bank[i] != 0; i++) {
    z = bank[i]->getZinssatz() * bank[i]->getSaldo() / 360.0;
    bank[i]->einzahlen((int) z);
  }
  for (i = 0; bankNr[i] != 0; i++) {
    z = bankNr[i]->getZinssatz() * bankNr[i]->getSaldo() / 360.0;
    bankNr[i]->einzahlen((int) z);
  }
  
  // Alle Konten ausgeben
  cout << "Nach einem Banktag:" << endl;
  for (i = 0; bank[i] != 0; i++) {
    cout << *bank[i] << endl;
  }
  for (i = 0; bankNr[i] != 0; i++) {
    cout << *bankNr[i] << endl;
  }
}
