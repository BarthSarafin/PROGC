/* Datei: konto.h
   Autor: Marc Rennhard, urspruenglich Peter Frueh
   Datum: 03.07.2006

   Spezifikation fuer die verschiedenen Konten;
   Teil von Kontoverwaltung */

#ifndef KONTO_H
#define KONTO_H

#include <iostream>
using namespace std;

/*
 * Spezifikation der Klasse Konto
 */
class Konto {
protected:
  char inhaber[30];
  int saldo;
  static double zinssatz;
public:
  Konto (char ih[]); 
  void einzahlen (int betrag); 
  virtual int auszahlen (int gewuenscht); 
  int getSaldo() const; 
  const char* getInhaber() const;
  virtual double getZinssatz() const; 
  static void setZinssatz(double z); 
};


/*
 * Spezifikation der Klasse Kontokorrent, virtual Vererbung
 * ist nur f�r Mehrfachvererbung (Nummernkontokorrent) notwendig
 */
class Kontokorrent : virtual public Konto {
protected:
  int limite;
  static double zinssatz; // Ueberdeckt zinssatz in Konto
public:
  Kontokorrent (char ih[], int lim);
  virtual int auszahlen (int gewuenscht); 
  virtual double getZinssatz() const;
  static void setZinssatz(double zs);
};


/*
 * Spezifikation der Klasse Nummernkonto, virtual Vererbung
 * ist nur f�r Mehrfachvererbung (Nummernkontokorrent) notwendig
 */
class Nummernkonto : virtual protected Konto {
protected:
  int nummer;
public:
  Nummernkonto (char ih[], int nr);
  int getNummer() const;

  // Wegen der protected Vererbung muss der public Zugriff
  // auf diese Methoden wieder explizit freigegeben werden
  void einzahlen (int betrag);
  virtual int auszahlen (int gewuenscht);
  int getSaldo() const;
  virtual double getZinssatz() const;
  static void setZinssatz(double zs);
};


/*
 * Spezifikation der Klasse Nummernkontokorrent
 */
class Nummernkontokorrent : protected Kontokorrent, public Nummernkonto {
public:
  Nummernkontokorrent(char ih[], int lim , int nr);
  virtual int auszahlen (int gewuenscht); 
  virtual double getZinssatz() const;
  static void setZinssatz(double zs);
};


/*
 * Funktionsdeklarationen
 */
ostream& operator << (ostream& os, const Konto& k);
ostream& operator << (ostream& os, const Nummernkonto& nk);

#endif
