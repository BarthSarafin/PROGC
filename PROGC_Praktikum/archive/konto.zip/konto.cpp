/* Datei: konto.cpp
   Autor: Marc Rennhard, urspruenglich Peter Frueh
   Datum: 03.07.2006

   Implementierung fuer die verschiedenen Konten;
   Teil von Kontoverwaltung */

#include <cstring>
#include <iostream>
#include "konto.h"
using namespace std;

/*
 * Implementierung der Klasse Konto
 */
double Konto::zinssatz = 0.0;

Konto::Konto (char ih[]) : saldo(0) {
  strcpy (inhaber, ih); 
}

void Konto::einzahlen (int betrag) {
  saldo += betrag;
}

int Konto::auszahlen (int gewuenscht) {
  if (saldo >= gewuenscht) {
    saldo -= gewuenscht;
    return gewuenscht;
  } else {
    int erhalten = saldo;
    saldo = 0;
    return erhalten;
  }
}

int Konto::getSaldo() const {
  return saldo;
}

const char* Konto::getInhaber() const {
  return inhaber;
}

double Konto::getZinssatz() const {
  return zinssatz;
}

void Konto::setZinssatz(double zs) {
  zinssatz = zs;
}


/*
 * Implementierung der Klasse Kontokorrent
 */
double Kontokorrent::zinssatz = 0.0;

Kontokorrent::Kontokorrent (char ih[], int lim)
  : Konto(ih), limite(lim) {}

int Kontokorrent::auszahlen (int gewuenscht) {
  if (saldo + limite >= gewuenscht) {
    saldo -= gewuenscht;
    return gewuenscht;
  } else {
    int erhalten = saldo + limite;
    saldo = -limite;
    return erhalten;
  }
}

double Kontokorrent::getZinssatz() const {
  return zinssatz;
}

void Kontokorrent::setZinssatz(double zs) {
  zinssatz = zs;
}


/*
 * Implementierung der Klasse Nummernkonto
 */
Nummernkonto::Nummernkonto (char ih[], int nr)
  : Konto(ih) , nummer(nr) {}

int Nummernkonto::getNummer() const {
  return nummer;
}

void Nummernkonto::einzahlen (int betrag) {
  Konto::einzahlen(betrag);
}

int Nummernkonto::auszahlen (int gewuenscht) {
  return Konto::auszahlen(gewuenscht);
}

int Nummernkonto::getSaldo() const {
  return Konto::getSaldo();
}

double Nummernkonto::getZinssatz() const {
  return Konto::getZinssatz();
}

void Nummernkonto::setZinssatz(double zs) {
  Konto::setZinssatz(zs);
}


/*
 * Implementierung der Klasse Nummernkontokorrent
 * 
 * Achtung; wegen der virtuellen Mehrfachvererbung muss auch der
 * Constructor von Konto mittels Initializer angegeben werden,
 * da sonst der Default-Kontsruktor verwendet w�rde!
 */
Nummernkontokorrent::Nummernkontokorrent (char ih[], int lim, int nr)
  : Nummernkonto(ih, nr), Kontokorrent(ih, lim), Konto(ih) {}

int Nummernkontokorrent::auszahlen (int gewuenscht) {
  return Kontokorrent::auszahlen(gewuenscht);
} 

double Nummernkontokorrent::getZinssatz() const {
  return Kontokorrent::getZinssatz();}

void Nummernkontokorrent::setZinssatz(double zs) {
  Kontokorrent::setZinssatz(zs);
}


/*
 * Overloading der Output-Operatoren, muessen als
 * Funktionen ueberladen werden
 */
ostream& operator << (ostream& os, const Konto& k) {
  os << k.getInhaber() << '\t' << k.getSaldo() << '\t' <<
        k.getZinssatz();
  return os;
}

ostream& operator << (ostream& os, const Nummernkonto& nk) {
  os << nk.getNummer() << "\t\t" << nk.getSaldo() << '\t' <<
        nk.getZinssatz();
  return os;
}
