/* person.cpp
   Autor: Marc Rennhard
   Datum: 05.06.2006

   Implementierung fuer Person; Teil von
   Personenverwaltung++ */

#include <cstring>
#include "person.h"
using namespace std;

/* persCmp vergleicht zwei Personen alphabetisch, zuerst
   Name, dann Vorname ind zuletzt das Alter. Falls p1 < p2
   wird -1 zur�ckgegeben, falls p1 > p2 wird 1 zur�ckgegeben
   und falls p1 = p2 wird 0 zur�ckgegeben. */
int persCmp(const Person& p1, const Person& p2) {
  int str;

  str = strcmp(p1.name, p2.name);
  if (str < 0) {
    return -1;
  } else if (str > 0) {
    return 1;
  } else {

    /* Die Namen sind gleich, vergleiche die Vornamen */
    str = strcmp(p1.firstname, p2.firstname);
    if (str < 0) {
      return -1;
    } else if (str > 0) {
      return 1;
    } else {

      /* Die Vornamen sind gleich, vergleiche das Alter */
      if (p1.age < p2.age) {
        return -1;
      } else if (p1.age > p2.age) {
        return 1;
      } else {
        return 0;
      }
    }
  }
}
