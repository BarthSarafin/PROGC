/* main.cpp
   Autor: Marc Rennhard
   Datum: 05.06.2006

   Hauptprogramm der Personenverwaltung++ */

#include <iostream>
#include "person.h"
#include "list.h"
using namespace std;

int main (int argc, char** argv) {
  Person p;
  ListElement l;
  char action = 'x'; 
  char c;
  int rounds, i;

  /* Initialisierung des Rings */
  init(l);

  /* Kommandozeilenparameter pr�fen, ob Memory-Demo Mode verwendet wird */
  if (argc == 2) {

    /* Memory-Demo Mode */
    rounds = atoi(argv[1]);
    cout << "Press enter to start inserting persons" << endl;
    cin.get();
    cout << "Inserting " << rounds << " persons..." << endl;
    strcpy(p.name, "A");
    strcpy(p.firstname, "A");
    for (i = rounds; i > 0; --i) {
      p.age = i;
      insertPers(l, p);
    }
    cout << "done" << endl;
    cout << "Press enter to start removing persons" << endl;
    cin.get();
    cout << "Removing " << rounds << " persons..." << endl;
    for (i = 1; i <= rounds ; ++i) {
      p.age = i;
      removePers(l, p);
    }
    cout << "done" << endl;
    strcpy(p.name, "B");
    strcpy(p.firstname, "B");
    cout << "Press enter to start inserting persons again" << endl;
    cin.get();
    cout << "Inserting " << rounds << " persons..." << endl;
    for (i = rounds; i > 0; --i) {
      p.age = i;
      insertPers(l, p);
    }
    cout << "done" << endl;
    cout << "Press enter to start removing persons" << endl;
    cin.get();
    cout << "Removing " << rounds << " persons..." << endl;
    for (i = 1; i <= rounds ; ++i) {
      p.age = i;
      removePers(l, p);
    }
    cout << "done" << endl;
    cout << "Press enter to quit" << endl;
    cin.get();
    exit(0);
  }
    
  /* Schleife, bis Benutzer beendet */
  while ((action != 'E') && (action != 'e')) {
    cout << "I(insert), R(emove), S(how), C(lear), E(nd): ";
    action = cin.get();
    cin.get();
    switch (action) {
    case 'I': case 'i': 
      cout << "Enter name, first name and age: ";
      cin >> p.name >> p.firstname >> p.age;
      cin.get();
      insertPers(l, p); 
      break;
    case 'R': case 'r':
      cout << "Enter name, first name and age: ";
      cin >> p.name >> p.firstname >> p.age;
      cin.get();
      if (!removePers(l, p)) {
        cout << "No such person" << endl;
      }
      break;
    case 'S': case 's': 
      show(l);
      break;
    case 'C': case 'c':
      clear(l);
      break;
    case 'E': case 'e':
      break;
    default:
      cout << "Illegal operation" << endl;
    }
  }
}
