/* list.cpp
   Autor: Marc Rennhard
   Datum: 05.06.2006

   Implementierung der Liste; Teil von
   Personenverwaltung++ */

#include <iostream>
#include "list.h"
#include "person.h"
using namespace std;

/* Initialisierung der Liste; enthaelt ein Element, das auf
   sich selbst zeigt */
void init(ListElement& l) {
  l.next = &l;
}

/* Fuegt ein Element alphabetisch in die Liste ein */
void insertPers(ListElement& l, const Person& p) {
  ListElement *nl = (ListElement*) new ListElement;
  ListElement *temp = &l;
  nl->content = p;
  while ((temp->next != &l) && (persCmp(temp->next->content, p) < 0)) {
    temp = temp->next;
  }
  nl->next = temp->next;
  temp->next = nl;
}

/* Entfernt das erste Auftreten eines Elements von der Liste */
int removePers(ListElement& l, const Person& p) {
  ListElement *temp = &l;
  while ((temp->next != &l) && (persCmp(temp->next->content, p) < 0)) {
    temp = temp->next;
  }
  if (persCmp(temp->next->content, p) == 0) {
    ListElement *rem = temp->next;
    temp->next = temp->next->next;
    delete rem;
    return 1;
  } else {
    return 0;
  }
}

/* Gibt die Elemente der Liste alphabetisch aus */
void show (const ListElement& l) {
  const ListElement *temp = &l;
  while (temp->next != &l) {
    cout << temp->next->content.name <<  ", " << temp->next->content.firstname <<
      " (" << temp->next->content.age << ")" << endl;
    temp = temp->next;
  }
}

/* Entfernt saemtliche ELemente aus der Liste */
void clear (ListElement& l) {
  ListElement *temp = l.next;
  while (temp != &l) {
    ListElement *rem = temp;
    temp = temp->next;
    delete rem;
  }
  init(l);
}
