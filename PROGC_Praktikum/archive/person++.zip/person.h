/* person.h
   Autor: Marc Rennhard
   Datum: 05.06.2006

   Headerdatei fuer Person; Teil von
   Personenverwaltung++ */

#ifndef PERSON_H
#define PERSON_H

/* Eine Person */
typedef struct {
  char name[20];
  char firstname[20];
  unsigned age;
} Person;

/* Funktion auf der Person */
int persCmp(const Person& p1, const Person& p2);

#endif
