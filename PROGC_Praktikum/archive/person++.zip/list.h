/* list.h
   Autor: Marc Rennhard
   Datum: 05.06.2006

   Headerdatei fuer Listenoperationen; Teil von
   Personenverwaltung++ */

#ifndef LIST_H
#define LIST_H
#include "person.h"

/* Element in der Liste */
typedef struct LE {
  Person content;
  struct LE *next;
} ListElement;

/* Funktionen auf der Liste. Man koennte bei insertPers und removePers
   auch statt der Adressen der Strukturen direkt die Strukturen �bergeben, 
   was aber ineffizienter w�re weil eine Struktur bei der Parameter�bergabe
   komplett kopiert wird  */
void init(ListElement& l);
void insertPers(ListElement& l, const Person& p);
int removePers(ListElement& l, const Person& p);
void show(const ListElement& l);
void clear(ListElement& l);

#endif
