/* Datei: zeit.h
   Autor: Marc Rennhard
   Datum: 12.6.2007

   Spezifikation von Zeit
*/

#ifndef ZEIT_H
#define ZEIT_H

#include <iostream>
#include "zeit.h"
using namespace std;

class Zeit {
 private:

  // Instanzvariablen f�r Stunden, Minuten und Sekunden
  int stunden;
  int minuten;
  int sekunden;
  
  // Private Methode, um den Ueberlauf der Zeit zu korrigieren
  void checkUeberlauf();
   
 public:
  
  // Constructors
  Zeit();
  Zeit(int std, int min, int sek);

  // Get-Methoden einer Zeit
  int getStunden() const;
  int getMinuten() const;
  int getSekunden() const;
  
  // Set-Methoden einer Zeit
  void setStunden(int std);
  void setMinuten(int min);
  void setSekunden(int sek);
  
  // Klassenmethode, m den Ueberlauf der Zeit zu korrigieren
  static void checkUeberlauf(int& std, int& min, int& sek);
  
  // Ueberladene Operatoren
  Zeit operator + (const Zeit& right) const;
  Zeit& operator ++ ();
  bool operator == (const Zeit& right);
  Zeit operator ++ (int);
  bool operator > (const Zeit& right);
  Zeit operator + (int right) const;
};

// Funktionsdeklarationen
ostream& operator << (ostream& os, const Zeit& z);
istream& operator >> (istream& is, Zeit& z);

#endif
