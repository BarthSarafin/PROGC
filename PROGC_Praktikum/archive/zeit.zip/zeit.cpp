/* Datei: zeit.cpp
   Autor: Marc Rennhard
   Datum: 12.6.2007

   Implementierung von Zeit 
*/

#include <iostream>
#include "zeit.h"
using namespace std;

/* Default Constructor */
Zeit::Zeit() : stunden(0), minuten(0), sekunden(0) {
}

/* Constructor, erzeugen einer Zeit aus Parametern */
Zeit::Zeit(int std, int min, int sek) {
  if (std >= 0 && std <= 24 && min >= 0 && min <= 60 && sek >= 0 && sek <= 60) {
    stunden = std;
    minuten = min;
    sekunden = sek;
  } else {
    stunden = 0;
    minuten = 0;
    sekunden = 0;
  }
}

/* Get-Methoden auf einer Zeit */
int Zeit::getStunden() const {
  return stunden;
}
int Zeit::getMinuten() const {
  return minuten;
}
int Zeit::getSekunden() const {
  return sekunden;
}

/* Set-Methoden auf einer Zeit */
void Zeit::setStunden(int std) {
  if (std >= 0 && std <= 24) {
    stunden = std;
  }
}
void Zeit::setMinuten(int min) {
  if (min >= 0 && min <= 60) {
    minuten = min;
  }
}
void Zeit::setSekunden(int sek) {
  if (sek >= 0 && sek <= 60) {
    sekunden = sek;
  }
}

/* Methode, um Ueberlauf der Zeit zu korrigieren */
void Zeit::checkUeberlauf() {
  if (sekunden >= 60) {
    minuten += sekunden/60;
    sekunden %= 60;
  }
  if (minuten >= 60) {
    stunden += minuten/60;
    minuten -= 60;
  }
  if (stunden >= 24) {
    stunden %= 24;
  }
}

/* Statische Methode, um Ueberlauf der Zeit zu korrigieren */
void Zeit::checkUeberlauf(int& std, int& min, int& sek) {
  if (sek >= 60) {
    min += sek/60;
    sek %= 60;
  }
  if (min >= 60) {
    std += min/60;
    min %= 60;
  }
  if (std >= 24) {
    std %= 24;
  }
}

/* Addition zweier Zeiten: + Operator */
Zeit Zeit::operator + (const Zeit& right) const {
  int std;
  int min;
  int sek;

  sek = sekunden + right.sekunden;
  min = minuten + right.minuten;
  std = stunden + right.stunden;
  Zeit::checkUeberlauf(std, min, sek);
  Zeit temp(std, min, sek);
  return temp;
}

/* Inkrement einer Zeit um 1 Sekunde: Prefix ++ Operator */
Zeit& Zeit::operator ++ () {
  ++sekunden;
  checkUeberlauf();
  return *this;
}

/*  Vergleich zweier Zeiten: == Operator */
bool Zeit::operator == (const Zeit& right) {
  if (stunden == right.stunden && minuten == right.minuten && 
      sekunden == right.sekunden) {
    return true;
  } else {
    return false;
  }
}

/* Inkrement einer Zeit um 1 Sekunde: Postfix ++ Operator */
Zeit Zeit::operator ++ (int) {
  Zeit temp(stunden, minuten, sekunden);
  ++sekunden;
  checkUeberlauf();
  return temp;
}

/*  Vergleich zweier Zeiten : > Operator */
bool Zeit::operator > (const Zeit& right) {
  if (stunden > right.stunden) {
    return true;
  } else if (stunden < right.stunden) {
    return false;
  }
  if (minuten > right.minuten) {
    return true;
  } else if (minuten < right.minuten) {
    return false;
  }  
  if (sekunden > right.sekunden) {
    return true;
  }
  return false;
}

/* Addition einer Anzahl Sekunden zu einer Zeit: + Operator */
Zeit Zeit::operator + (int right) const {
  int std;
  int min;
  int sek;

  sek = sekunden + right;
  min = minuten;
  std = stunden;
  Zeit::checkUeberlauf(std, min, sek);
  Zeit temp(std, min, sek);
  return temp;
}

/* Ausgabe einer Zeit: Output Operator << */
ostream& operator << (ostream& os, const Zeit& z) {
  if (z.getStunden() <= 9) {
    os << '0';
  }
  os << z.getStunden() << ":";
  if (z.getMinuten() <= 9) {
    os << '0';
  }
  os << z.getMinuten() << ":";
  if (z.getSekunden() <= 9) {
    os << '0';
  }
  return os << z.getSekunden();
}

/* Eingabe einer Zeit: Input Operator >> */
istream& operator >> (istream& is, Zeit& z) {
  int std;
  int min;
  int sek;
  
  cout << "Eingabe einer Zeit: ";
  cout.flush();
  is >> std >> min >> sek;
  if (std >= 0 && std <= 24 && min >= 0 && min <= 60 && sek >= 0 && sek <= 60) {
    z.setStunden(std);
    z.setMinuten(min);
    z.setSekunden(sek);
  }
  return is;
}
