/* Datei: main.cpp
   Autor: Marc Rennhard
   Datum: 12.6.2007

   Hauptprogramm um die Klasse Zeit zu testen
*/

#include <iostream>
#include "zeit.h"
using namespace std;

int main() {
  Zeit z1(25, 0, 0);
  Zeit z2(8, 15, 35);
  
  /* Test Constructor und << Operator */
  cout << "Test Constructor und << Operator:" << endl;
  cout << "Sollte 00:00:00 sein: " << z1 << endl;
  cout << "Sollte 08:15:35 sein: " << z2 << endl << endl;;
  
  /* Test + Operator (zwei Zeiten) */
  cout << "Test + Operator (zwei Zeiten):" << endl;
  Zeit z3(21, 48, 56);
  Zeit z4 = z1 + z3;
  Zeit z5 = z2 + z3;
  cout << "Sollte 21:48:56 sein: " << z4 << endl;
  cout << "Sollte 06:04:31 sein: " << z5 << endl << endl;
  
  /* Test ++ Prefix-Operator */
  cout << "Test ++ Prefix-Operator: " << endl;
  cout << "Sollte 21:48:57 / 21:48:57 sein: " << ++z3 << " / " << z3 << endl << endl;
  
  /* Test == Operator */
  cout << "Test == Operator: " << endl;
  Zeit z6(10, 11, 12);
  Zeit z7(10, 11, 12);
  Zeit z8(10, 11, 13);
  cout << "Sollte 1 (true) sein: " << (z6 == z7) << endl;
  cout << "Sollte 0 (false) sein: " << (z6 == z8) << endl << endl;;
  
  /* Test >> Operator */
  cout << "Test >> Operator: " << endl;
  Zeit z9, z10;
  cin >> z9;
  cout << "Sollte der eben eingegebene Wert sein: " << z9 << endl;
  cin >> z9 >> z10;
  cout << "Sollte die beiden eben eingegebenen Werte sein: " << 
          z9 << " / " << z10 << endl << endl;;  
  
  /* Test ++ Postfix-Operator */
  cout << "Test ++ Postfix-Operator: " << endl;
  Zeit z11(3, 59, 59);
  cout << "Sollte 03:59:59 / 04:00:00 sein: " << z11++ << " / " << z11 << endl << endl;

  /* Test + Operator (Zeit und Wert in Sekunden) */
  cout << "Test + Operator (Zeit und Wert in Sekunden): " << endl;
  Zeit z12(1, 0, 0);
  cout << "Sollte 02:00:00 sein: " << (z12 + 3600) << endl;
  cout << "Sollte 20:03:20 sein: " << (z12 + 155000) << endl << endl;
  
  /* Test > Operator */
  cout << "Test > Operator: " << endl;
  cout << "Sollte 1 (true) sein: " << (z8 > z7) << endl;
  cout << "Sollte 0 (false) sein: " << (z6 > z7) << endl;
}
