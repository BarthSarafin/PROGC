/* Datei: auto.cpp
   Autor: Marc Rennhard
   Datum: 04.06.2007

   Implementierung von Auto 
*/

#include <iostream>
#include <cstring>
#include "auto.h"
using namespace std;

/* Default Constructor */
Auto::Auto() : brand(NULL), topSpeed(0), horsePower(0) {
  if (Auto::debug) {
    cout << "  ** Default Constructor (" << "---" << " " << horsePower 
         << " PS, " << topSpeed << " km/h)" << endl;
  }
}

/* Copy Constructor, komplette Kopie eines Autos */
Auto::Auto(const Auto& a) : topSpeed(a.topSpeed), 
  horsePower(a.horsePower)  {
  brand = new char[strlen(a.brand) + 1];
  strcpy(brand, a.brand);
  if (Auto::debug) {
    cout << "  ** Copy Constructor    (" << brand << " " << horsePower 
         << " PS, " << topSpeed << " km/h)" << endl;
  }
}

/* Constructor, erzeugen eines Autos aus Parametern */
Auto::Auto(const char* brandInit, int topSpeedInit, 
  int horsePowerInit) : topSpeed(topSpeedInit), 
  horsePower(horsePowerInit) {
  brand = new char[strlen(brandInit) + 1];
  strcpy(brand, brandInit);
  
  if (Auto::debug) {
    cout << "  ** Param Constructor   (" << brand << " " << horsePower 
         << " PS, " << topSpeed << " km/h)" << endl;
  }
}

/* Destructor */
Auto::~Auto() {
  if (Auto::debug) {
    cout << "  ** Destructor          (" << brand << " " << horsePower 
         << " PS, " << topSpeed << " km/h)" << endl;
  }
  delete [] brand;
}

/* Gibt ein Auto nach cout aus */
void Auto::print() const {
  cout << brand << " (" << horsePower << " PS, " << topSpeed << " km/h)" << endl;
}

/* Gibt den TopSpeed des Autos zur�ck */
int Auto::getTopSpeed() const {
  return topSpeed;
}

/* Setzt die Debug Variable */
void Auto::setDebug(bool on) {
    debug = on;
}

/* Initialisiert die statische Variable DEBUG auf true */
bool Auto::debug = true;

Auto getFaster1(Auto a1, Auto a2) {
  if (a1.getTopSpeed() >= a2.getTopSpeed()) {
    return a1;
  }
  return a2;
}

const Auto& getFaster2(const Auto& a1, const Auto& a2) {
  if (a1.getTopSpeed() >= a2.getTopSpeed()) {
    return a1;
  }
  return a2;
}
