/* Datei: auto.h
   Autor: Marc Rennhard
   Datum: 04.06.2007

   Spezifikation von Auto
*/

#ifndef AUTO_H
#define AUTO_H

class Auto {
 private:

  // Statische Variable zum Debuggen
  static bool debug;
  
  // Instanzvariablen
  char* brand;
  int topSpeed;
  int horsePower;
  
 public:
  
  // Constructors and Destructor
  Auto();
  Auto(const Auto& a);
  Auto(const char* brandInit, int topSpeedInit, int horsePowerInit);
  ~Auto();

  // Methoden auf einem Auto
  static void setDebug(bool on);
  void print() const;
  int getTopSpeed() const;
};

Auto getFaster1(Auto a1, Auto a2);
const Auto& getFaster2(const Auto& a1, const Auto& a2);
#endif
