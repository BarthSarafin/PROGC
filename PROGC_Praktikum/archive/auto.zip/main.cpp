/* Datei: main.cpp
   Autor: Marc Rennhard
   Datum: 04.06.2007

   Hauptprogramm um die Klasse Auto zu testen
*/

#include <iostream>
#include "auto.h"
using namespace std;

int main() {
  char marke[100];
  int vMax;
  int ps;
  
  /*
   * Aufgabe 1: Auto eingeben, auf Stack kreieren, ausgeben, tunen
   */
  cout << "Aufgabe 1" << endl;
  cout << "Auto eingeben (Marke, PS, vMax): ";
  cin >> marke >> ps >> vMax;
  Auto a1 = Auto(marke, vMax, ps);
  a1.print();
 
  /*
   * Aufgabe 2: Zweites Auto eingeben, ausgeben
   */
  cout << endl << "Aufgabe 2" << endl;
  cout << "Auto eingeben (Marke, PS, vMax): ";
  cin >> marke >> ps >> vMax;
  Auto a2 = Auto(marke, vMax, ps);
  a2.print();
  
  /*
   * Aufgabe 3: Autos vergleichen mit erster Funktion
   */
  cout << endl << "Aufgabe 3" << endl;
  Auto a3 = getFaster1(a1, a2);
  a3.print();
  
  /*
   * Aufgabe 4: Autos vergleichen mit zweiter Funktion
   */
  cout << endl << "Aufgabe 4" << endl;
  Auto a4 = getFaster2(a1, a2);
  a4.print();
  
  /*
   * Aufgabe 5: Sehr viele Autos auf dem Heap erzeugen
   * und jeweils l�schen
   */
  Auto::setDebug(false);
  Auto* a5;
  cout << endl << "Aufgabe 5" << endl;
  cout << "Erzeuge 1000000 Autos:" << endl;
  for (int i = 1; i <= 10000000; i++) {
    a5 = new Auto(a1);
    if (i % 500000 == 0) {
      cout << i << " erzeugt" << endl;
    }
    delete a5;
  }
  cout << "done" << endl;
    
  /*
   * Aufgabe 6: Sehr viele Autos auf dem Heap erzeugen
   * und jeweils l�schen
   */
  Auto* a6;
  cout << endl << "Aufgabe 6" << endl;
  cout << "Erzeuge 1000000 Autos:" << endl;
  for (int i = 1; i <= 10000000; i++) {
    a6 = new Auto(a1);
    if (i % 500000 == 0) {
      cout << i << " erzeugt" << endl;
    }
  }
  cout << "done" << endl;

  cout << endl << "Ende aller Aufgaben" << endl;
}
